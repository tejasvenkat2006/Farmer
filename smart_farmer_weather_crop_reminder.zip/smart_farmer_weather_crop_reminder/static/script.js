const $ = (id) => document.getElementById(id);
let currentLanguage = "en";
const saved = () => JSON.parse(localStorage.getItem("smartFarmerReminders") || "[]");
const store = (items) => localStorage.setItem("smartFarmerReminders", JSON.stringify(items));

$("langBtn").addEventListener("click", () => {
  currentLanguage = currentLanguage === "en" ? "ta" : "en";
  document.querySelectorAll("[data-en]").forEach(el => el.textContent = el.dataset[currentLanguage]);
  $("langBtn").textContent = currentLanguage === "en" ? "தமிழ்" : "English";
});

const weatherText = {
  0:["Clear sky","☀️"],1:["Mainly clear","🌤️"],2:["Partly cloudy","⛅"],3:["Overcast","☁️"],
  45:["Fog","🌫️"],48:["Depositing rime fog","🌫️"],51:["Light drizzle","🌦️"],53:["Drizzle","🌦️"],55:["Heavy drizzle","🌧️"],
  61:["Slight rain","🌦️"],63:["Moderate rain","🌧️"],65:["Heavy rain","🌧️"],71:["Slight snow","🌨️"],80:["Rain showers","🌦️"],81:["Rain showers","🌧️"],82:["Heavy rain showers","⛈️"],95:["Thunderstorm","⛈️"]
};
function describe(code){ return weatherText[code] || ["Variable conditions","🌤️"]; }

$("locationForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const place = $("locationInput").value.trim();
  if (!place) return;
  $("weatherUpdated").textContent = "Loading weather…";
  try {
    const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(place)}&count=1&language=en&format=json`);
    if (!geoRes.ok) throw new Error("Could not search for this location.");
    const geo = await geoRes.json();
    if (!geo.results?.length) throw new Error("Location not found. Try a nearby town or district.");
    const loc = geo.results[0];
    const weatherRes = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&forecast_days=5&timezone=auto`);
    if (!weatherRes.ok) throw new Error("Weather service is temporarily unavailable.");
    const data = await weatherRes.json();
    const current = data.current, daily = data.daily;
    const [desc, icon] = describe(current.weather_code);
    $("locationLabel").textContent = [loc.name,loc.admin1,loc.country].filter(Boolean).join(", ");
    $("weatherPlace").textContent = loc.name;
    $("temperature").textContent = Math.round(current.temperature_2m);
    $("weatherDescription").textContent = desc;
    $("weatherIcon").textContent = icon;
    $("humidity").textContent = `${current.relative_humidity_2m}%`;
    $("wind").textContent = `${Math.round(current.wind_speed_10m)} km/h`;
    $("rain").textContent = `${Math.max(...daily.precipitation_probability_max)}%`;
    $("weatherRange").textContent = `Feels like ${Math.round(current.apparent_temperature)}°C · ${current.precipitation} mm current precipitation`;
    $("weatherUpdated").textContent = "Updated just now";
    $("forecast").innerHTML = daily.time.map((date,i) => {
      const [label,emoji] = describe(daily.weather_code[i]);
      const day = new Date(date+"T00:00:00").toLocaleDateString("en",{weekday:"short",day:"numeric"});
      return `<article class="forecast-card panel"><span>${day}</span><div class="f-icon">${emoji}</div><strong class="f-temp">${Math.round(daily.temperature_2m_max[i])}° / ${Math.round(daily.temperature_2m_min[i])}°</strong><span>${daily.precipitation_probability_max[i]}% rain</span></article>`;
    }).join("");
  } catch (error) {
    $("weatherUpdated").textContent = error.message;
    $("weatherUpdated").style.color = "#b34a37";
  }
});

function renderReminders(){
  const items = saved().sort((a,b) => a.date.localeCompare(b.date));
  $("reminderCount").textContent = items.length;
  if (!items.length) {
    $("reminderList").innerHTML = '<div class="empty-state">No reminders yet. Add your first crop reminder.</div>';
    return;
  }
  $("reminderList").innerHTML = items.map(item => `
    <div class="reminder-item">
      <div><strong>${escapeHTML(item.crop)} · ${escapeHTML(item.task)}</strong>
      <small>Sown: ${item.sowing} &nbsp;|&nbsp; Reminder: ${item.date}</small></div>
      <button class="delete-btn" data-id="${item.id}" aria-label="Delete reminder">Delete</button>
    </div>`).join("");
  document.querySelectorAll(".delete-btn").forEach(btn => btn.addEventListener("click", () => {
    store(saved().filter(item => item.id !== btn.dataset.id)); renderReminders();
  }));
}
function escapeHTML(value){return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("cropForm").addEventListener("submit", event => {
  event.preventDefault();
  const crop = $("cropName").value, sowing = $("sowingDate").value, task = $("taskName").value.trim(), date = $("reminderDate").value;
  if (!crop || !sowing || !task || !date) return;
  if (date < sowing) { alert("Reminder date should be on or after the sowing date."); return; }
  const items = saved();
  items.push({id:crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),crop,sowing,task,date});
  store(items); event.target.reset(); renderReminders();
});
$("sowingDate").valueAsDate = new Date();
$("reminderDate").valueAsDate = new Date(Date.now()+86400000);
renderReminders();
