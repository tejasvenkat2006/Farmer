# Smart Farmer – Weather & Crop Reminder System

A beginner-friendly college project built with **Python Flask, HTML, CSS and JavaScript**. It helps farmers view local weather forecasts and create crop activity reminders.

## Features
- Search a village, town or city and view current weather.
- Five-day forecast with temperature and rain probability.
- Humidity and wind-speed information.
- Add crop, sowing date, task and reminder date.
- Delete reminders.
- English/Tamil interface labels.
- Responsive layout for mobile and desktop.
- Reminders are stored in the browser on the device using localStorage.

## Requirements
- Python 3.9 or newer
- Internet connection for live weather data
- A modern browser

## Run locally

1. Extract the ZIP file.
2. Open the extracted project folder in VS Code.
3. Open Terminal in that folder.
4. Create and activate a virtual environment (recommended):

   **Windows**
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

5. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

6. Start the app:
   ```bash
   python app.py
   ```

7. Open `http://127.0.0.1:5000` in your browser.

## Upload to GitHub

Create a new empty repository on GitHub. In the project folder, run:

```bash
git init
git add .
git commit -m "Initial Smart Farmer project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your own GitHub repository URL.

## Weather data
Weather and geocoding are fetched from the public Open-Meteo APIs:
- https://open-meteo.com/
- https://geocoding-api.open-meteo.com/

No API key is required for normal non-commercial use. Review the provider's terms before public/commercial deployment.

## Important project notes
- Crop reminders are currently saved only in the same browser/device. They are not yet synced between users or devices.
- This version does not send background push notifications. It displays saved reminders in the app.
- Weather forecasts are estimates, not guarantees. Farmers should confirm important decisions with local agricultural extension officers.
- Crop schedules depend on variety, soil, irrigation, season and local recommendations. The app lets the farmer create their own tasks rather than presenting generic dates as expert advice.

## Suggested future improvements
- User login and cloud database (MySQL/PostgreSQL).
- SMS/WhatsApp notifications.
- Automatic reminders based on crop stage and locally approved crop calendars.
- Voice assistant and full Tamil translations.
- Rain alerts for saved farm locations.
